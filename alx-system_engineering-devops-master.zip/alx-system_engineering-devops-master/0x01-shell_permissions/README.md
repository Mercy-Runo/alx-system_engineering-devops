Shell permissions projects from the ALX program
