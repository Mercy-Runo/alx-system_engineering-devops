a script that prints the absolute path name of the current working directory
A script to display the contents list of your current directory
