Shell project for ALX
